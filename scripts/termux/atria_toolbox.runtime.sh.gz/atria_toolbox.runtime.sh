#!/data/data/com.termux/files/usr/bin/bash
# Atria Toolbox - Termux 管理工具箱
# 面向仓库: https://github.com/ZZZdragondYNGPHX/Atria
# 默认分支: main
# License: AGPL-3.0
#
# 交互思路参考 mc10091009/st_manager.sh 的 Termux 工具箱，
# 本文件针对 Atria 的仓库结构、分支和数据布局独立重写。

set -o pipefail

# ---------- 基础配置 ----------
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
PURPLE='\033[0;35m'
BOLD='\033[1m'
DIM='\033[2m'
NC='\033[0m'

REPO_URL="https://github.com/ZZZdragondYNGPHX/Atria.git"
DEFAULT_BRANCH="main"

ATRIA_MAIN_DIR="$HOME/Atria"
ATRIA_SECOND_DIR="$HOME/Atria-2"
ATRIA_DIR="$ATRIA_MAIN_DIR"
CURRENT_INSTANCE="主实例 (Atria)"

TOOLBOX_NAME="atria_toolbox.sh"
TOOLBOX_PATH="$HOME/$TOOLBOX_NAME"
TOOLBOX_HOME="$HOME/.atria_toolbox"

# 程序保留在 Termux 私有目录；用户数据与备份放到 Android 共享存储。
# termux-setup-storage 成功后，$HOME/storage/shared 通常指向 /storage/emulated/0。
SHARED_STORAGE_LINK="${ATRIA_SHARED_STORAGE:-$HOME/storage/shared}"
ATRIA_MAIN_SHARED_DIR="$SHARED_STORAGE_LINK/Atria"
ATRIA_SECOND_SHARED_DIR="$SHARED_STORAGE_LINK/Atria-2"
ATRIA_SHARED_DIR="$ATRIA_MAIN_SHARED_DIR"
ATRIA_DATA_DIR="$ATRIA_SHARED_DIR/data"
BACKUP_DIR="$ATRIA_SHARED_DIR/backups"
EXPORT_DIR="$ATRIA_SHARED_DIR/exports"

LOG_FILE="$TOOLBOX_HOME/atria.log"
PID_FILE="$TOOLBOX_HOME/atria.pid"
KEEPALIVE_MAIN_FLAG="$TOOLBOX_HOME/atria.keepalive"
KEEPALIVE_SECOND_FLAG="$TOOLBOX_HOME/atria-2.keepalive"
KEEPALIVE_FLAG_FILE="$KEEPALIVE_MAIN_FLAG"
BATTERY_GUIDE_FLAG="$TOOLBOX_HOME/battery-guide-seen"
WAKELOCK_MANAGED_FLAG="$TOOLBOX_HOME/wakelock.managed"
SCRIPT_VERSION="v0.3.0"

# 把脚本放到这个仓库路径后，自更新即可直接工作。
SCRIPT_URL="${ATRIA_TOOLBOX_URL:-https://raw.githubusercontent.com/ZZZdragondYNGPHX/Atria/main/scripts/termux/atria_toolbox.sh}"
TAG_DISPLAY_LIMIT=12

mkdir -p "$TOOLBOX_HOME" 2>/dev/null || true

# 防止 source 运行，避免 exit 影响当前 Shell。
(return 0 2>/dev/null) && SOURCED=1 || SOURCED=0
if [ "$SOURCED" -eq 1 ]; then
    echo -e "${RED}[ERROR] 请使用 bash 运行本脚本，不要 source/. 执行。${NC}"
    return 1
fi

# ---------- 通用函数 ----------
info()  { echo -e "${GREEN}[INFO]${NC} $*"; }
warn()  { echo -e "${YELLOW}[WARN]${NC} $*"; }
error() { echo -e "${RED}[ERROR]${NC} $*"; }
pause() { read -r -p "按回车键继续..." _; }

confirm() {
    local prompt="$1"
    local default="${2:-n}"
    local answer
    if [ "$default" = "y" ]; then
        read -r -p "$prompt [Y/n]: " answer
        answer="${answer:-y}"
    else
        read -r -p "$prompt [y/N]: " answer
        answer="${answer:-n}"
    fi
    [[ "$answer" =~ ^[Yy]$ ]]
}

safe_delete_confirm() {
    local action="$1"
    warn "$action"
    warn "这是高风险操作。建议先备份。"
    confirm "确认继续？" n || return 1

    local code=$((RANDOM % 9000 + 1000))
    local input
    read -r -p "二次确认：请输入 $code ：" input
    [ "$input" = "$code" ]
}

is_termux() {
    [ -n "${PREFIX:-}" ] && [[ "$PREFIX" == *"com.termux"* ]]
}

node_major() {
    node -p 'process.versions.node.split(".")[0]' 2>/dev/null || echo 0
}

get_abs_path() {
    if command -v realpath >/dev/null 2>&1; then
        realpath "$1" 2>/dev/null
    elif command -v readlink >/dev/null 2>&1; then
        readlink -f "$1" 2>/dev/null
    else
        echo "$1"
    fi
}

repo_ok() {
    [ -d "$ATRIA_DIR/.git" ] && [ -f "$ATRIA_DIR/package.json" ] && [ -f "$ATRIA_DIR/server.js" ]
}

ensure_repo() {
    if ! repo_ok; then
        error "当前实例不是完整的 Atria 仓库：$ATRIA_DIR"
        return 1
    fi
}

ensure_config() {
    if [ ! -f "$ATRIA_DIR/config.yaml" ] && [ -f "$ATRIA_DIR/default/config.yaml" ]; then
        cp "$ATRIA_DIR/default/config.yaml" "$ATRIA_DIR/config.yaml"
        info "已从 default/config.yaml 初始化 config.yaml"
    fi
}

get_port() {
    local port="8000"
    if [ -f "$ATRIA_DIR/config.yaml" ]; then
        local p
        p=$(awk '/^[[:space:]]*port:[[:space:]]*[0-9]+[[:space:]]*$/ {print $2; exit}' "$ATRIA_DIR/config.yaml" 2>/dev/null)
        [[ "$p" =~ ^[0-9]+$ ]] && port="$p"
    fi
    echo "$port"
}

get_storage_mode() {
    local config="$ATRIA_DIR/config.yaml"
    [ -f "$config" ] || { echo "fs"; return; }
    awk '
        /^storage:[[:space:]]*$/ { in_storage=1; next }
        in_storage && /^[^[:space:]]/ { in_storage=0 }
        in_storage && /^[[:space:]]+mode:[[:space:]]*/ {
            gsub(/["\047]/, "", $2); print $2; exit
        }
    ' "$config" 2>/dev/null
}

current_ref_label() {
    if ! repo_ok; then
        echo "未安装"
        return
    fi
    local branch tag sha
    branch=$(git -C "$ATRIA_DIR" symbolic-ref --short -q HEAD 2>/dev/null || true)
    tag=$(git -C "$ATRIA_DIR" describe --tags --exact-match 2>/dev/null || true)
    sha=$(git -C "$ATRIA_DIR" rev-parse --short HEAD 2>/dev/null || true)
    if [ -n "$branch" ]; then
        echo "$branch @ $sha"
    elif [ -n "$tag" ]; then
        echo "tag:$tag @ $sha"
    else
        echo "detached @ $sha"
    fi
}

# ---------- 环境 ----------
install_termux_deps() {
    if ! command -v pkg >/dev/null 2>&1; then
        error "未检测到 Termux 的 pkg 命令。此工具箱仅针对 Termux。"
        return 1
    fi

    info "更新 Termux 软件源索引..."
    pkg update -y || return 1

    info "安装 Atria/工具箱所需依赖..."
    # nodejs 提供 node/npm；build-essential/python 为原生 npm 模块编译准备环境。
    pkg install -y \
        git curl nodejs python build-essential clang make pkg-config \
        tar jq lsof psmisc procps openssh
}

init_environment() {
    if ! is_termux; then
        warn "当前环境看起来不像 Termux；脚本仍会继续，但 Android 专用功能可能不可用。"
    fi

    local required=(git curl node npm python tar jq lsof fuser pgrep)
    local missing=()
    local cmd
    for cmd in "${required[@]}"; do
        command -v "$cmd" >/dev/null 2>&1 || missing+=("$cmd")
    done

    if [ ${#missing[@]} -gt 0 ]; then
        warn "缺少依赖：${missing[*]}"
        if confirm "自动安装 Termux 依赖？" y; then
            install_termux_deps || return 1
        else
            return 1
        fi
    fi

    local major
    major=$(node_major)
    if [ "$major" -lt 20 ] 2>/dev/null; then
        error "Atria 要求 Node.js >= 20；当前：$(node -v 2>/dev/null || echo 未安装)"
        info "可在 Termux 执行：pkg install nodejs"
        return 1
    fi

    info "Node.js: $(node -v) | npm: $(npm -v)"
}

install_node_modules() {
    ensure_repo || return 1
    cd "$ATRIA_DIR" || return 1
    info "安装生产依赖..."
    # 与 Atria start.sh 的策略保持一致，减少 Android/Termux 上安装脚本副作用。
    npm install \
        --no-save \
        --no-audit \
        --no-fund \
        --loglevel=error \
        --no-progress \
        --omit=dev \
        --ignore-scripts || return 1
    bash "$ATRIA_DIR/scripts/termux/fix-better-sqlite3.sh" || return 1
    prebuild_frontend_cache
}

# ---------- Android 共享存储 / 数据分离 ----------
shared_storage_display_path() {
    if [ -e "$SHARED_STORAGE_LINK" ]; then
        get_abs_path "$SHARED_STORAGE_LINK" 2>/dev/null || echo "$SHARED_STORAGE_LINK"
    else
        echo "/storage/emulated/0"
    fi
}

refresh_instance_storage_paths() {
    local shared_root="$SHARED_STORAGE_LINK"
    if [ -d "$SHARED_STORAGE_LINK" ]; then
        local resolved
        resolved=$(get_abs_path "$SHARED_STORAGE_LINK" 2>/dev/null || true)
        [ -n "$resolved" ] && shared_root="$resolved"
    fi

    if [ "$ATRIA_DIR" = "$ATRIA_SECOND_DIR" ]; then
        ATRIA_SHARED_DIR="$shared_root/Atria-2"
    else
        ATRIA_SHARED_DIR="$shared_root/Atria"
    fi
    ATRIA_DATA_DIR="$ATRIA_SHARED_DIR/data"
    BACKUP_DIR="$ATRIA_SHARED_DIR/backups"
    EXPORT_DIR="$ATRIA_SHARED_DIR/exports"
}

ensure_shared_storage() {
    if [ ! -d "$SHARED_STORAGE_LINK" ]; then
        if ! is_termux; then
            error "未找到 Android 共享存储：$SHARED_STORAGE_LINK"
            return 1
        fi
        warn "尚未授予 Termux 共享存储权限。"
        info "接下来会调用 termux-setup-storage，请在 Android 弹窗中允许文件访问。"
        if ! confirm "现在授权共享存储？" y; then
            return 1
        fi
        termux-setup-storage >/dev/null 2>&1 || true
        local n
        for n in $(seq 1 20); do
            [ -d "$SHARED_STORAGE_LINK" ] && break
            sleep 1
        done
    fi

    if [ ! -d "$SHARED_STORAGE_LINK" ]; then
        error "共享存储仍不可用。请手动执行：termux-setup-storage"
        return 1
    fi

    refresh_instance_storage_paths
    mkdir -p "$ATRIA_DATA_DIR" "$BACKUP_DIR" "$EXPORT_DIR" || {
        error "无法写入共享存储：$ATRIA_SHARED_DIR"
        return 1
    }

    local test_file="$ATRIA_SHARED_DIR/.atria-write-test.$$"
    if ! printf 'ok' > "$test_file" 2>/dev/null; then
        error "共享存储没有写入权限：$ATRIA_SHARED_DIR"
        return 1
    fi
    rm -f "$test_file"
    return 0
}

get_config_data_root() {
    local config="$ATRIA_DIR/config.yaml"
    [ -f "$config" ] || { echo "./data"; return; }
    local value
    value=$(awk '
        /^[[:space:]]*dataRoot:[[:space:]]*/ {
            sub(/^[[:space:]]*dataRoot:[[:space:]]*/, "", $0)
            gsub(/^["\047]|["\047]$/, "", $0)
            print $0
            exit
        }
    ' "$config" 2>/dev/null)
    [ -n "$value" ] && echo "$value" || echo "./data"
}

resolve_config_data_dir() {
    local root
    root=$(get_config_data_root)
    case "$root" in
        /*) echo "$root" ;;
        ~/*) echo "$HOME/${root#~/}" ;;
        *) echo "$ATRIA_DIR/${root#./}" ;;
    esac
}

set_config_data_root() {
    ensure_config
    local target="$ATRIA_DATA_DIR"
    local config="$ATRIA_DIR/config.yaml"
    local tmp="$config.tmp.$$"

    awk -v target="$target" '
        BEGIN { done=0 }
        !done && /^[[:space:]]*dataRoot:[[:space:]]*/ {
            print "dataRoot: " target
            done=1
            next
        }
        { print }
        END {
            if (!done) print "dataRoot: " target
        }
    ' "$config" > "$tmp" || { rm -f "$tmp"; return 1; }
    mv "$tmp" "$config"
}

has_files() {
    local dir="$1"
    [ -d "$dir" ] && find "$dir" -mindepth 1 -print -quit 2>/dev/null | grep -q .
}

# 仓库自带 data/.gitkeep；它不是用户数据，迁移判断时忽略。
has_meaningful_data() {
    local dir="$1"
    [ -d "$dir" ] && find "$dir" -mindepth 1 ! -name '.gitkeep' -print -quit 2>/dev/null | grep -q .
}

has_symlinks() {
    local dir="$1"
    [ -d "$dir" ] && find "$dir" -type l -print -quit 2>/dev/null | grep -q .
}

verify_data_copy() {
    local src="$1"
    local dst="$2"
    python - "$src" "$dst" <<'PYVERIFY'
import hashlib, os, sys
src, dst = sys.argv[1:3]

def manifest(root):
    out = {}
    for base, dirs, files in os.walk(root):
        for name in files:
            p = os.path.join(base, name)
            rel = os.path.relpath(p, root)
            if os.path.islink(p):
                continue
            h = hashlib.sha256()
            try:
                with open(p, 'rb') as f:
                    for chunk in iter(lambda: f.read(1024 * 1024), b''):
                        h.update(chunk)
                out[rel] = (os.path.getsize(p), h.hexdigest())
            except OSError as e:
                print(f"READ_ERROR {rel}: {e}", file=sys.stderr)
                raise
    return out

try:
    a = manifest(src)
    b = manifest(dst)
except Exception:
    sys.exit(2)

if a != b:
    missing = sorted(set(a) - set(b))[:20]
    extra = sorted(set(b) - set(a))[:20]
    changed = sorted(k for k in set(a) & set(b) if a[k] != b[k])[:20]
    if missing: print("MISSING:", *missing, sep="\n  ", file=sys.stderr)
    if extra: print("EXTRA:", *extra, sep="\n  ", file=sys.stderr)
    if changed: print("CHANGED:", *changed, sep="\n  ", file=sys.stderr)
    sys.exit(1)
print(f"verified_files={len(a)}")
PYVERIFY
}

migrate_private_data_to_shared() {
    ensure_repo || return 1
    ensure_shared_storage || return 1
    ensure_config

    local current legacy
    current=$(resolve_config_data_dir)
    legacy="$ATRIA_DIR/data"

    # 已经指向当前实例的共享 data 时，只做目录准备。
    if [ "$(get_abs_path "$current" 2>/dev/null || echo "$current")" = "$(get_abs_path "$ATRIA_DATA_DIR" 2>/dev/null || echo "$ATRIA_DATA_DIR")" ]; then
        set_config_data_root || return 1
        info "数据分离已启用：$(get_abs_path "$ATRIA_DATA_DIR" 2>/dev/null || echo "$ATRIA_DATA_DIR")"
        return 0
    fi

    # 对 sqlite 做额外提示：数据库也会随 dataRoot 进入共享存储。
    if [ "$(get_storage_mode)" = "sqlite" ]; then
        warn "当前存储后端为 sqlite。迁移后 SQLite 数据库也会位于 Android 共享存储。"
        warn "共享存储由 Android/FUSE 管理，数据库性能和锁可靠性通常不如 Termux 私有目录。"
        confirm "仍然继续数据分离？" n || return 1
    fi

    if has_symlinks "$current"; then
        error "当前数据目录中存在符号链接；Android 共享存储不适合直接迁移符号链接。"
        info "请先处理这些链接："
        find "$current" -type l -print 2>/dev/null | head -n 20
        return 1
    fi

    local current_has_data=0 target_has_data=0
    has_meaningful_data "$current" && current_has_data=1
    has_meaningful_data "$ATRIA_DATA_DIR" && target_has_data=1

    # 典型重装场景：新仓库的 ./data 只有 .gitkeep，但共享目录里已经有用户数据。
    # 此时直接重新绑定 dataRoot，绝不覆盖共享数据。
    if [ "$target_has_data" -eq 1 ] && [ "$current_has_data" -eq 0 ]; then
        set_config_data_root || { error "修改 config.yaml 失败。"; return 1; }
        info "检测到已有共享数据，已直接重新绑定，不执行覆盖迁移。"
        echo "数据：$(get_abs_path "$ATRIA_DATA_DIR" 2>/dev/null || echo "$ATRIA_DATA_DIR")"
        return 0
    fi

    # 两边都有真实数据时无法自动判断哪一份更新，停止以避免覆盖。
    if [ "$target_has_data" -eq 1 ] && [ "$current_has_data" -eq 1 ]; then
        error "私有数据与共享数据同时存在，为防止覆盖，自动迁移已停止。"
        echo "当前数据：$current"
        echo "共享数据：$ATRIA_DATA_DIR"
        info "请先创建备份并确认应保留哪一份数据。"
        return 1
    fi

    if [ -d "$current" ] && [ "$current_has_data" -eq 1 ]; then
        warn "检测到旧数据，需要迁移到 Android 共享存储："
        echo "  从：$current"
        echo "  到：$(get_abs_path "$ATRIA_DATA_DIR" 2>/dev/null || echo "$ATRIA_DATA_DIR")"
        confirm "复制并校验旧数据？" y || return 1

        info "正在复制数据；旧数据在校验成功前不会删除。"
        mkdir -p "$ATRIA_DATA_DIR" || return 1
        cp -R "$current"/. "$ATRIA_DATA_DIR"/ || {
            error "复制失败；旧数据保持不变。"
            return 1
        }

        info "正在逐文件 SHA-256 校验..."
        if ! verify_data_copy "$current" "$ATRIA_DATA_DIR"; then
            error "数据校验失败。不会切换 dataRoot，也不会删除旧数据。"
            return 1
        fi
        info "数据校验通过。"
    fi

    set_config_data_root || { error "修改 config.yaml 失败。"; return 1; }

    # 仓库跟踪 data/.gitkeep，因此不移动/替换整个 data 目录，避免把 Git 工作区弄脏。
    # 旧用户数据暂时原地保留为安全副本；确认共享数据正常后可从菜单清理。
    if [ -d "$legacy" ] && has_meaningful_data "$legacy"; then
        warn "旧 Termux 私有 data 仍原地保留，当前运行已切换到共享 dataRoot。"
        info "确认新数据正常后，可在“数据管理”中清理旧私有 data。"
    fi

    info "数据分离完成。"
    echo "程序：$ATRIA_DIR"
    echo "数据：$(get_abs_path "$ATRIA_DATA_DIR" 2>/dev/null || echo "$ATRIA_DATA_DIR")"
    echo "备份：$(get_abs_path "$BACKUP_DIR" 2>/dev/null || echo "$BACKUP_DIR")"
}

ensure_data_separation() {
    ensure_repo || return 1
    ensure_shared_storage || return 1
    ensure_config

    local current target
    current=$(resolve_config_data_dir)
    target="$ATRIA_DATA_DIR"
    if [ "$(get_abs_path "$current" 2>/dev/null || echo "$current")" != "$(get_abs_path "$target" 2>/dev/null || echo "$target")" ]; then
        warn "当前 Atria 尚未使用共享数据目录。"
        migrate_private_data_to_shared || return 1
    else
        mkdir -p "$ATRIA_DATA_DIR" "$BACKUP_DIR" "$EXPORT_DIR"
    fi
}

show_storage_status() {
    refresh_instance_storage_paths
    local configured="$(get_config_data_root 2>/dev/null || echo './data')"
    local resolved="$(resolve_config_data_dir 2>/dev/null || echo '-')"
    local shared_real="$(get_abs_path "$ATRIA_SHARED_DIR" 2>/dev/null || echo "$ATRIA_SHARED_DIR")"
    echo -e "${BOLD}程序目录：${NC}$ATRIA_DIR"
    echo -e "${BOLD}config dataRoot：${NC}$configured"
    echo -e "${BOLD}实际数据目录：${NC}$resolved"
    echo -e "${BOLD}共享目录：${NC}$shared_real"
    echo -e "${BOLD}备份目录：${NC}$(get_abs_path "$BACKUP_DIR" 2>/dev/null || echo "$BACKUP_DIR")"
    if [ -d "$SHARED_STORAGE_LINK" ]; then
        echo -e "共享存储权限：${GREEN}可用${NC}"
    else
        echo -e "共享存储权限：${RED}未初始化${NC}"
    fi
}

cleanup_private_data_backups() {
    ensure_repo || return 1
    local legacy="$ATRIA_DIR/data"
    local has_legacy=0
    has_meaningful_data "$legacy" && has_legacy=1

    shopt -s nullglob
    local old=("$ATRIA_DIR"/data.private-backup-*)
    shopt -u nullglob

    if [ "$has_legacy" -eq 0 ] && [ ${#old[@]} -eq 0 ]; then
        info "没有可清理的旧 Termux 私有用户数据。"
        return 0
    fi

    warn "此操作只清理旧的 Termux 私有数据副本，不删除 Android 共享数据。"
    [ "$has_legacy" -eq 1 ] && echo "  $legacy（保留仓库自带 .gitkeep）"
    [ ${#old[@]} -gt 0 ] && printf '  %s\n' "${old[@]}"
    safe_delete_confirm "清理上述旧私有数据" || return 1

    if [ "$has_legacy" -eq 1 ]; then
        shopt -s dotglob nullglob
        local item
        for item in "$legacy"/*; do
            [ "$(basename "$item")" = ".gitkeep" ] && continue
            rm -rf -- "$item"
        done
        shopt -u dotglob nullglob
    fi
    [ ${#old[@]} -gt 0 ] && rm -rf -- "${old[@]}"
    info "旧私有数据已清理；共享数据保持不变。"
}

# ---------- Git / 版本管理 ----------
show_tags() {
    ensure_repo || return 1
    local remote_tags
    remote_tags=$(git -C "$ATRIA_DIR" ls-remote --tags --refs --sort=-version:refname origin) || return 1
    local tags=()
    mapfile -t tags < <(printf '%s\n' "$remote_tags" | sed -n "1,${TAG_DISPLAY_LIMIT}s#.*refs/tags/##p")
    if [ ${#tags[@]} -eq 0 ]; then
        warn "未检测到 Tag。"
        return 1
    fi
    echo -e "${YELLOW}远程 Tag（按版本名排序，最多 ${TAG_DISPLAY_LIMIT} 个）：${NC}"
    local i
    for i in "${!tags[@]}"; do
        printf " %2d. %s\n" "$((i + 1))" "${tags[$i]}"
    done
}

worktree_clean() {
    [ -z "$(git -C "$ATRIA_DIR" status --porcelain 2>/dev/null)" ]
}

require_clean_worktree() {
    ensure_repo || return 1
    if ! worktree_clean; then
        error "仓库存在未提交修改，已停止代码切换，避免覆盖文件。"
        git -C "$ATRIA_DIR" status --short
        return 1
    fi
}

fetch_repo_refs() {
    info "同步 main 增量..."
    git -C "$ATRIA_DIR" fetch --no-tags origin '+refs/heads/main:refs/remotes/origin/main'
}

prepare_code_change() {
    local action="$1"
    require_clean_worktree || return 1

    local running
    running=$(find_atria_pids 2>/dev/null || true)
    if [ -n "$running" ]; then
        warn "当前实例正在运行。切换代码前建议停止 Atria。"
        confirm "现在停止当前实例并继续${action}？" y || return 1
        stop_atria || return 1
    fi

    if confirm "${action}前创建数据备份？" y; then
        backup_data || return 1
    fi
    fetch_repo_refs || return 1
}

post_code_change() {
    ensure_config
    ensure_instance_default_port
    ensure_data_separation || {
        error "共享数据目录未就绪。代码已切换，但不会继续安装依赖。"
        return 1
    }
    install_node_modules || return 1
    info "当前版本：$(current_ref_label)"
}

switch_to_remote_branch() {
    local branch="$1"
    if ! git -C "$ATRIA_DIR" show-ref --verify --quiet "refs/remotes/origin/$branch"; then
        error "远程分支不存在：$branch"
        return 1
    fi

    if git -C "$ATRIA_DIR" show-ref --verify --quiet "refs/heads/$branch"; then
        git -C "$ATRIA_DIR" switch "$branch" || return 1
        if ! git -C "$ATRIA_DIR" merge --ff-only "origin/$branch"; then
            error "本地分支与远程发生分叉，工具箱不会强制覆盖本地提交。"
            info "请手动处理 Git 历史后再重试。"
            return 1
        fi
    else
        git -C "$ATRIA_DIR" switch -c "$branch" --track "origin/$branch" || return 1
    fi
}

install_atria() {
    if [ -e "$ATRIA_DIR" ]; then
        warn "目标目录已存在：$ATRIA_DIR"
        if repo_ok; then
            info "检测到已有 Atria。只有确认重装后才会删除程序目录；共享数据默认保留。"
            if confirm "重装前先备份共享数据？" y; then
                backup_data || { error "备份失败，已取消重装。"; return 1; }
            fi
        fi
        safe_delete_confirm "删除当前程序目录并重新安装：$ATRIA_DIR" || { info "已取消。"; return 1; }
        stop_atria >/dev/null 2>&1 || true
        rm -rf "$ATRIA_DIR" || return 1
    fi

    init_environment || return 1
    ensure_shared_storage || return 1

    info "下载 Atria main 最新版本（不含其他分支和完整历史）..."
    git clone --depth 1 --single-branch --no-tags --branch "$DEFAULT_BRANCH" "$REPO_URL" "$ATRIA_DIR" || { error "克隆失败。"; return 1; }

    if git -C "$ATRIA_DIR" show-ref --verify --quiet "refs/remotes/origin/$DEFAULT_BRANCH"; then
        switch_to_remote_branch "$DEFAULT_BRANCH" || return 1
    else
        error "未找到默认分支：$DEFAULT_BRANCH"
        return 1
    fi

    ensure_config
    ensure_instance_default_port
    if ! ensure_data_separation; then
        warn "程序已安装，但共享数据目录尚未配置完成。启动前必须完成数据分离。"
        return 1
    fi
    install_node_modules || return 1
    info "Atria 安装完成：$(current_ref_label)"
}

update_current_branch() {
    ensure_repo || return 1
    local branch old_sha remote_sha
    branch=$(git -C "$ATRIA_DIR" symbolic-ref --short -q HEAD 2>/dev/null || true)
    if [ -z "$branch" ]; then
        error "当前处于 Tag/Commit detached 状态，请从版本管理切换到分支后再更新。"
        return 1
    fi

    require_clean_worktree || return 1
    fetch_repo_refs || return 1
    if ! git -C "$ATRIA_DIR" show-ref --verify --quiet "refs/remotes/origin/$branch"; then
        error "远程不存在当前分支：$branch"
        return 1
    fi

    old_sha=$(git -C "$ATRIA_DIR" rev-parse HEAD)
    remote_sha=$(git -C "$ATRIA_DIR" rev-parse "origin/$branch")
    if [ "$old_sha" = "$remote_sha" ]; then
        info "当前分支已经是最新：$branch @ ${old_sha:0:10}"
        return 0
    fi

    local running
    running=$(find_atria_pids 2>/dev/null || true)
    if [ -n "$running" ]; then
        confirm "更新前停止正在运行的 Atria？" y || return 1
        stop_atria || return 1
    fi
    if confirm "更新前创建数据备份？" y; then
        backup_data || { error "备份失败，更新已停止。"; return 1; }
    fi

    if ! git -C "$ATRIA_DIR" merge --ff-only "origin/$branch"; then
        error "无法快进更新。工具箱不会强制覆盖本地提交。"
        return 1
    fi
    post_code_change
}

choose_managed_branch() {
    SELECTED_BRANCH=""
    echo "1. main（推荐）"
    echo "2. release"
    echo "3. main"
    echo "0. 取消"
    local choice
    read -r -p "请选择分支：" choice
    case "$choice" in
        1) SELECTED_BRANCH="main" ;;
        2) SELECTED_BRANCH="release" ;;
        3) SELECTED_BRANCH="main" ;;
        0) return 1 ;;
        *) error "无效选项"; return 1 ;;
    esac
}

switch_branch_interactive() {
    ensure_repo || return 1
    choose_managed_branch || return 1
    prepare_code_change "切换分支" || return 1
    switch_to_remote_branch "$SELECTED_BRANCH" || return 1
    post_code_change
}

switch_tag_interactive() {
    ensure_repo || return 1
    require_clean_worktree || return 1
    ensure_atria_origin || return 1
    show_tags || return 1
    local tag
    read -r -p "输入完整 Tag：" tag
    [ -n "$tag" ] || return 1
    git check-ref-format "refs/tags/$tag" || { error "Tag 格式无效。"; return 1; }
    git -C "$ATRIA_DIR" fetch --depth 1 --no-tags origin "refs/tags/$tag:refs/tags/$tag" || return 1

    local running
    running=$(find_atria_pids 2>/dev/null || true)
    if [ -n "$running" ]; then
        confirm "切换 Tag 前停止 Atria？" y || return 1
        stop_atria || return 1
    fi
    if confirm "切换 Tag 前创建数据备份？" y; then
        backup_data || { error "备份失败，已停止切换。"; return 1; }
    fi

    git -C "$ATRIA_DIR" checkout --detach "tags/$tag" || return 1
    post_code_change
}

switch_commit_interactive() {
    ensure_repo || return 1
    require_clean_worktree || return 1
    ensure_atria_origin || return 1
    echo -e "${YELLOW}本地已下载提交（最多 15 条）：${NC}"
    git -C "$ATRIA_DIR" log -n 15 --oneline --decorate
    local target
    read -r -p "输入 Commit Hash（未下载的提交需完整 40 位）：" target
    [ -n "$target" ] || return 1
    [[ "$target" =~ ^[0-9a-fA-F]{4,40}$ ]] || { error "请输入有效的 Commit Hash。"; return 1; }
    if ! git -C "$ATRIA_DIR" cat-file -e "$target^{commit}" 2>/dev/null; then
        [ "${#target}" -eq 40 ] || { error "本地不存在此提交，请输入完整 40 位 Hash。"; return 1; }
        git -C "$ATRIA_DIR" fetch --depth 1 --no-tags origin "$target" || return 1
    fi

    local running
    running=$(find_atria_pids 2>/dev/null || true)
    if [ -n "$running" ]; then
        confirm "切换 Commit 前停止 Atria？" y || return 1
        stop_atria || return 1
    fi
    if confirm "切换 Commit 前创建数据备份？" y; then
        backup_data || { error "备份失败，已停止切换。"; return 1; }
    fi

    git -C "$ATRIA_DIR" checkout --detach "$target" || return 1
    post_code_change
}

show_recent_commits() {
    ensure_repo || return 1
    echo -e "${YELLOW}当前：$(current_ref_label)${NC}"
    info "仅显示本地已下载的提交（最多 15 条）。"
    git -C "$ATRIA_DIR" log -n 15 --oneline --decorate
}

version_menu() {
    while true; do
        clear
        echo -e "${CYAN}========== Atria 版本管理 ==========${NC}"
        echo "当前：$(current_ref_label)"
        echo ""
        echo "1. 更新当前分支"
        echo "2. 切换分支（main / release / main）"
        echo "3. 切换到 Tag"
        echo "4. 切换到 Commit"
        echo "5. 查看最近提交"
        echo "0. 返回"
        read -r -p "请选择：" choice
        case "$choice" in
            1) update_current_branch; pause ;;
            2) switch_branch_interactive; pause ;;
            3) switch_tag_interactive; pause ;;
            4) switch_commit_interactive; pause ;;
            5) show_recent_commits; pause ;;
            0) return ;;
            *) error "无效选项"; pause ;;
        esac
    done
}

# ---------- 备份 / 恢复 ----------
backup_data() {
    ensure_repo || return 1
    ensure_config
    ensure_shared_storage || return 1

    local timestamp backup_file mode data_dir
    timestamp=$(date +"%Y%m%d_%H%M%S")
    backup_file="$BACKUP_DIR/atria_backup_${timestamp}.tar.gz"
    local seq=0
    while [ -e "$backup_file" ]; do
        seq=$((seq + 1))
        backup_file="$BACKUP_DIR/atria_backup_${timestamp}_${seq}.tar.gz"
    done
    mode=$(get_storage_mode)
    [ -n "$mode" ] || mode="fs"
    data_dir=$(resolve_config_data_dir)

    mkdir -p "$BACKUP_DIR"

    local internal_items=()
    [ -f "$ATRIA_DIR/config.yaml" ] && internal_items+=("config.yaml")
    [ -f "$ATRIA_DIR/secrets.json" ] && internal_items+=("secrets.json")
    [ -f "$ATRIA_DIR/.env" ] && internal_items+=(".env")
    [ -d "$ATRIA_DIR/plugins" ] && internal_items+=("plugins")
    [ -d "$ATRIA_DIR/public/scripts/extensions/third-party" ] && internal_items+=("public/scripts/extensions/third-party")

    info "存储后端：$mode"
    if [ "$mode" = "mysql" ] || [ "$mode" = "postgres" ]; then
        warn "当前使用外部数据库。备份包含本地 data/附件/配置/插件，不包含远程数据库表数据。"
    fi

    local tar_args=(-czf "$backup_file")
    local has_any=0

    if [ -d "$data_dir" ]; then
        # 无论 dataRoot 在哪里，都统一以 data/ 作为备份包内路径。
        tar_args+=(-C "$(dirname "$data_dir")" "$(basename "$data_dir")")
        has_any=1
    fi
    if [ ${#internal_items[@]} -gt 0 ]; then
        tar_args+=(-C "$ATRIA_DIR" "${internal_items[@]}")
        has_any=1
    fi

    if [ "$has_any" -eq 0 ]; then
        error "没有找到可备份的数据。"
        return 1
    fi

    info "正在创建共享存储备份..."
    if tar "${tar_args[@]}"; then
        info "备份完成：$(get_abs_path "$backup_file" 2>/dev/null || echo "$backup_file")"
        warn "该备份位于手机共享存储，可能包含 API Key/数据库连接信息，请妥善保管。"
    else
        rm -f "$backup_file"
        error "备份失败。"
        return 1
    fi
}

archive_is_safe() {
    local archive="$1"
    local entry
    while IFS= read -r entry; do
        [ -z "$entry" ] && continue
        [[ "$entry" == /* ]] && return 1
        [[ "/$entry/" == *"/../"* ]] && return 1
    done < <(tar -tzf "$archive" 2>/dev/null)
    return 0
}

restore_data() {
    ensure_repo || return 1
    ensure_shared_storage || return 1
    ensure_data_separation || return 1

    shopt -s nullglob
    local files=("$BACKUP_DIR"/atria_backup_*.tar.gz "$HOME/atria_backups"/atria_backup_*.tar.gz "$HOME"/atria_backup_*.tar.gz)
    shopt -u nullglob

    if [ ${#files[@]} -eq 0 ]; then
        error "未找到 Atria 备份。目录：$BACKUP_DIR"
        return 1
    fi

    echo "可用备份："
    local i
    for i in "${!files[@]}"; do
        printf " %2d. %s\n" "$((i + 1))" "${files[$i]}"
    done

    local idx archive
    read -r -p "选择序号：" idx
    [[ "$idx" =~ ^[0-9]+$ ]] || { error "无效序号"; return 1; }
    [ "$idx" -ge 1 ] && [ "$idx" -le "${#files[@]}" ] || { error "序号超范围"; return 1; }
    archive="${files[$((idx - 1))]}"

    tar -tzf "$archive" >/dev/null 2>&1 || { error "备份包损坏或格式不正确。"; return 1; }
    archive_is_safe "$archive" || { error "备份包包含不安全路径，已拒绝恢复。"; return 1; }

    warn "恢复会覆盖当前共享 data 与同名配置/插件文件。"
    safe_delete_confirm "从 $(basename "$archive") 恢复到当前 Atria 实例" || return 1

    info "恢复前创建当前快照..."
    backup_data || { error "当前快照备份失败，为避免数据丢失已停止恢复。"; return 1; }

    local stage="$TOOLBOX_HOME/restore-stage.$$"
    rm -rf "$stage"
    mkdir -p "$stage" || return 1
    if ! tar -xzf "$archive" -C "$stage"; then
        rm -rf "$stage"
        error "解包失败。"
        return 1
    fi

    # 兼容旧备份：旧格式中的 data/ 也会被迁移到当前共享 dataRoot。
    if [ -d "$stage/data" ]; then
        rm -rf "$ATRIA_DATA_DIR.restore-new"
        mkdir -p "$ATRIA_DATA_DIR.restore-new" || { rm -rf "$stage"; return 1; }
        cp -R "$stage/data"/. "$ATRIA_DATA_DIR.restore-new"/ || { rm -rf "$stage"; return 1; }
        if ! verify_data_copy "$stage/data" "$ATRIA_DATA_DIR.restore-new"; then
            rm -rf "$stage" "$ATRIA_DATA_DIR.restore-new"
            error "恢复数据校验失败，当前数据未替换。"
            return 1
        fi
        local old_restore="$ATRIA_DATA_DIR.restore-old-$(date +%Y%m%d_%H%M%S)"
        if [ -d "$ATRIA_DATA_DIR" ]; then
            mv "$ATRIA_DATA_DIR" "$old_restore" || { rm -rf "$stage"; return 1; }
        fi
        mv "$ATRIA_DATA_DIR.restore-new" "$ATRIA_DATA_DIR" || return 1
        rm -rf "$old_restore"
    fi

    local item
    for item in config.yaml secrets.json .env plugins; do
        if [ -e "$stage/$item" ]; then
            rm -rf "$ATRIA_DIR/$item"
            cp -R "$stage/$item" "$ATRIA_DIR/$item" || { rm -rf "$stage"; return 1; }
        fi
    done
    if [ -d "$stage/public/scripts/extensions/third-party" ]; then
        mkdir -p "$ATRIA_DIR/public/scripts/extensions"
        rm -rf "$ATRIA_DIR/public/scripts/extensions/third-party"
        cp -R "$stage/public/scripts/extensions/third-party" "$ATRIA_DIR/public/scripts/extensions/third-party" || {
            rm -rf "$stage"; return 1;
        }
    fi
    rm -rf "$stage"

    # 备份里的旧 config.yaml 可能写着 ./data；恢复后重新锁定到共享目录。
    set_config_data_root || return 1
    info "恢复完成。数据仍位于 Android 共享存储。建议重启 Atria。"
}

# ---------- 进程 / 端口 / Android 保活 ----------
read_pid() {
    [ -f "$PID_FILE" ] || return 1
    local pid
    pid=$(cat "$PID_FILE" 2>/dev/null)
    [[ "$pid" =~ ^[0-9]+$ ]] || return 1
    kill -0 "$pid" 2>/dev/null || return 1
    echo "$pid"
}

find_atria_pids_for_dir() {
    local dir="$1" escaped
    escaped=$(printf '%s' "$dir/server.js" | sed 's/[][\\.^$*+?{}|()]/\\&/g')
    pgrep -f "node .*${escaped}" 2>/dev/null || true
}

find_atria_pids() {
    find_atria_pids_for_dir "$ATRIA_DIR"
}

flag_for_dir() {
    local dir="$1"
    if [ "$dir" = "$ATRIA_SECOND_DIR" ]; then
        echo "$KEEPALIVE_SECOND_FLAG"
    else
        echo "$KEEPALIVE_MAIN_FLAG"
    fi
}

cleanup_stale_keepalive_flags() {
    local flag dir removed=0
    for dir in "$ATRIA_MAIN_DIR" "$ATRIA_SECOND_DIR"; do
        flag=$(flag_for_dir "$dir")
        if [ -f "$flag" ] && [ -z "$(find_atria_pids_for_dir "$dir")" ]; then
            rm -f "$flag"
            removed=1
        fi
    done

    # 如果工具箱管理的所有保活进程都已经消失，顺手释放由工具箱申请的全局 Wake Lock。
    if [ "$removed" -eq 1 ] && [ ! -f "$KEEPALIVE_MAIN_FLAG" ] && [ ! -f "$KEEPALIVE_SECOND_FLAG" ] && [ -f "$WAKELOCK_MANAGED_FLAG" ]; then
        if command -v termux-wake-unlock >/dev/null 2>&1; then
            termux-wake-unlock >/dev/null 2>&1 || true
        fi
        rm -f "$WAKELOCK_MANAGED_FLAG"
    fi
}

any_keepalive_enabled() {
    cleanup_stale_keepalive_flags
    [ -f "$KEEPALIVE_MAIN_FLAG" ] || [ -f "$KEEPALIVE_SECOND_FLAG" ]
}

ensure_wake_lock_cli() {
    if command -v termux-wake-lock >/dev/null 2>&1 && command -v termux-wake-unlock >/dev/null 2>&1; then
        return 0
    fi
    warn "未检测到 Termux 自带的 Wake Lock 命令。"
    if command -v pkg >/dev/null 2>&1 && confirm "尝试修复 termux-tools？" y; then
        pkg install termux-tools -y || return 1
    fi
    command -v termux-wake-lock >/dev/null 2>&1 && command -v termux-wake-unlock >/dev/null 2>&1
}

release_wake_lock_if_unused() {
    cleanup_stale_keepalive_flags
    if [ -f "$KEEPALIVE_MAIN_FLAG" ] || [ -f "$KEEPALIVE_SECOND_FLAG" ]; then
        return 0
    fi
    [ -f "$WAKELOCK_MANAGED_FLAG" ] || return 0
    if command -v termux-wake-unlock >/dev/null 2>&1; then
        termux-wake-unlock >/dev/null 2>&1 || true
    fi
    rm -f "$WAKELOCK_MANAGED_FLAG"
}

port_pids() {
    local port="$1"
    local out=""
    if command -v lsof >/dev/null 2>&1; then
        out=$(lsof -tiTCP:"$port" -sTCP:LISTEN 2>/dev/null || true)
    fi
    if [ -z "$out" ] && command -v fuser >/dev/null 2>&1; then
        out=$(fuser "$port"/tcp 2>/dev/null || true)
    fi
    echo "$out" | tr ' ' '\n' | sed '/^$/d' | sort -u
}

show_port_usage() {
    local port
    port=$(get_port)
    local pids
    pids=$(port_pids "$port")
    info "配置端口：$port"
    if [ -z "$pids" ]; then
        info "端口未检测到监听进程。"
        return 0
    fi

    warn "端口 $port 正在被以下 PID 使用："
    local pid
    for pid in $pids; do
        printf "  PID %-7s " "$pid"
        ps -p "$pid" -o args= 2>/dev/null || echo "(无法读取命令行)"
    done
    return 1
}

set_port_value() {
    local new="$1"
    ensure_config
    local tmp="$ATRIA_DIR/config.yaml.tmp.$$"
    awk -v p="$new" '
        BEGIN { done=0 }
        !done && /^[[:space:]]*port:[[:space:]]*[0-9]+[[:space:]]*$/ {
            print "port: " p; done=1; next
        }
        { print }
        END { if (!done) print "port: " p }
    ' "$ATRIA_DIR/config.yaml" > "$tmp" || { rm -f "$tmp"; return 1; }
    mv "$tmp" "$ATRIA_DIR/config.yaml"
}

get_port_for_dir() {
    local dir="$1" config="$1/config.yaml" port="8000" p
    if [ -f "$config" ]; then
        p=$(awk '/^[[:space:]]*port:[[:space:]]*[0-9]+[[:space:]]*$/ {print $2; exit}' "$config" 2>/dev/null)
        [[ "$p" =~ ^[0-9]+$ ]] && port="$p"
    fi
    echo "$port"
}

find_free_port() {
    local start="${1:-8001}" p
    for ((p=start; p<=65535; p++)); do
        [ -z "$(port_pids "$p")" ] && { echo "$p"; return 0; }
    done
    return 1
}

ensure_instance_default_port() {
    [ "$ATRIA_DIR" = "$ATRIA_SECOND_DIR" ] || return 0
    ensure_config
    local current main_port new
    current=$(get_port)
    main_port=$(get_port_for_dir "$ATRIA_MAIN_DIR")
    if [ "$current" = "$main_port" ]; then
        new=$(find_free_port 8001) || return 1
        set_port_value "$new" || return 1
        info "分身实例端口与主实例冲突，已自动调整为：$new"
    fi
}

prepare_start() {
    ensure_repo || return 1
    cleanup_stale_keepalive_flags
    ensure_config
    init_environment || return 1
    ensure_data_separation || {
        error "共享数据目录未就绪，已停止启动，避免继续写入 Termux 私有 data。"
        return 1
    }

    if [ ! -d "$ATRIA_DIR/node_modules" ]; then
        warn "node_modules 不存在，正在补装依赖。"
        install_node_modules || return 1
    else
        bash "$ATRIA_DIR/scripts/termux/fix-better-sqlite3.sh" || return 1
    fi

    local own_pids
    own_pids=$(find_atria_pids)
    if [ -n "$own_pids" ]; then
        warn "当前实例已在运行：$(echo "$own_pids" | tr '\n' ' ')"
        return 1
    fi

    local port foreign
    port=$(get_port)
    foreign=$(port_pids "$port")
    if [ -n "$foreign" ]; then
        error "端口 $port 已被占用，已停止启动。"
        show_port_usage
        return 1
    fi
}

start_background_process() {
    cd "$ATRIA_DIR" || return 1
    mkdir -p "$TOOLBOX_HOME"
    : > "$LOG_FILE"

    nohup node "$ATRIA_DIR/server.js" >>"$LOG_FILE" 2>&1 &
    local pid=$!
    echo "$pid" > "$PID_FILE"
    sleep 2

    if kill -0 "$pid" 2>/dev/null; then
        info "Atria 已在后台启动。PID=$pid"
        info "地址：http://127.0.0.1:$(get_port)"
        return 0
    fi

    rm -f "$PID_FILE"
    error "启动失败，最近日志："
    tail -n 50 "$LOG_FILE" 2>/dev/null
    return 1
}

start_foreground() {
    prepare_start || return 1
    rm -f "$KEEPALIVE_FLAG_FILE"
    release_wake_lock_if_unused
    cd "$ATRIA_DIR" || return 1
    info "前台调试启动。Ctrl+C 停止 Atria 后会返回工具箱。"
    NODE_COMPILE_CACHE="${NODE_COMPILE_CACHE:-$ATRIA_DIR/node_modules/.cache/atria-node}" node "$ATRIA_DIR/server.js"
    local rc=$?
    echo ""
    info "Atria 前台进程已退出（code=$rc）。"
    return "$rc"
}

start_background() {
    prepare_start || return 1
    rm -f "$KEEPALIVE_FLAG_FILE"
    release_wake_lock_if_unused
    info "普通后台启动 Atria..."
    start_background_process
}

termux_package_name() {
    if [ -n "${TERMUX_APP_PACKAGE:-}" ]; then
        echo "$TERMUX_APP_PACKAGE"
        return
    fi
    local detected=""
    detected=$(printf '%s' "${PREFIX:-}" | sed -n 's#^/data/data/\([^/]*\)/.*#\1#p')
    echo "${detected:-com.termux}"
}

open_termux_battery_settings() {
    local package_name
    package_name=$(termux_package_name)
    if ! command -v am >/dev/null 2>&1; then
        warn "无法调用 Android 设置。请手动进入 Termux 应用信息 → 电池。"
        return 1
    fi

    am start -a android.settings.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS \
        -d "package:$package_name" >/dev/null 2>&1 && return 0
    am start -a android.settings.APP_BATTERY_SETTINGS \
        -d "package:$package_name" >/dev/null 2>&1 && return 0
    am start -a android.settings.IGNORE_BATTERY_OPTIMIZATION_SETTINGS \
        >/dev/null 2>&1 && return 0
    am start -a android.settings.APPLICATION_DETAILS_SETTINGS \
        -d "package:$package_name" >/dev/null 2>&1 && return 0

    warn "无法自动打开设置。请手动把 Termux 电池策略设为“不限制/无限制”。"
    return 1
}

show_battery_guide() {
    echo ""
    echo -e "${BOLD}Android 保活建议：${NC}"
    echo "- Termux 电池策略：不限制 / 无限制"
    echo "- 允许后台活动、自启动（若系统提供）和通知"
    echo "- 最近任务中锁定 Termux（部分国产 ROM 有效）"
    echo "- 日常运行 Atria 使用“保活启动”，Wake Lock 由工具箱自动管理"
    echo "- 手动强制停止 Termux、系统极端省电或 OEM 清理仍可能终止进程"
}

ensure_battery_guide() {
    [ -f "$BATTERY_GUIDE_FLAG" ] && return 0
    warn "首次使用保活模式，建议先放宽 Termux 的电池后台限制。"
    show_battery_guide
    if confirm "现在打开 Termux 电池设置？" y; then
        open_termux_battery_settings || true
        read -r -p "设置完成后回到 Termux，按回车继续..." _
    fi
    touch "$BATTERY_GUIDE_FLAG"
}

start_keepalive() {
    prepare_start || return 1
    ensure_wake_lock_cli || {
        error "Wake Lock 命令不可用，无法进入保活模式。"
        return 1
    }

    info "获取 Termux Wake Lock..."
    if ! termux-wake-lock >/dev/null 2>&1; then
        error "Wake Lock 获取失败。"
        return 1
    fi
    touch "$WAKELOCK_MANAGED_FLAG"

    info "保活后台启动 Atria..."
    if ! start_background_process; then
        release_wake_lock_if_unused
        return 1
    fi

    touch "$KEEPALIVE_FLAG_FILE"
    ensure_battery_guide
    info "保活模式已启用：后台运行 + Wake Lock。"
}

stop_atria() {
    local pids pidfile_pid
    pids=$(find_atria_pids)
    pidfile_pid=$(read_pid 2>/dev/null || true)
    if [ -n "$pidfile_pid" ] && ! echo "$pids" | grep -qx "$pidfile_pid"; then
        pids="$pids${pids:+$'\n'}$pidfile_pid"
    fi
    pids=$(echo "$pids" | sed '/^$/d' | sort -u)

    if [ -z "$pids" ]; then
        info "未检测到当前实例的 Atria 进程。"
        rm -f "$PID_FILE" "$KEEPALIVE_FLAG_FILE"
        release_wake_lock_if_unused
        return 0
    fi

    info "正在停止 PID：$(echo "$pids" | tr '\n' ' ')"
    kill $pids 2>/dev/null || true

    local n alive p
    for n in 1 2 3 4 5 6 7 8; do
        alive=""
        for p in $pids; do kill -0 "$p" 2>/dev/null && alive="$alive $p"; done
        [ -z "$alive" ] && break
        sleep 1
    done

    alive=""
    for p in $pids; do kill -0 "$p" 2>/dev/null && alive="$alive $p"; done
    if [ -n "$alive" ]; then
        warn "进程未正常退出，强制停止：$alive"
        kill -9 $alive 2>/dev/null || true
    fi

    rm -f "$PID_FILE" "$KEEPALIVE_FLAG_FILE"
    release_wake_lock_if_unused
    info "Atria 已停止。"
}

restart_current_mode() {
    local keepalive=0
    cleanup_stale_keepalive_flags
    [ -f "$KEEPALIVE_FLAG_FILE" ] && keepalive=1
    stop_atria || true
    sleep 1
    if [ "$keepalive" -eq 1 ]; then
        start_keepalive
    else
        start_background
    fi
}

atria_status() {
    refresh_instance_storage_paths
    cleanup_stale_keepalive_flags

    echo -e "${BOLD}实例：${NC}$CURRENT_INSTANCE"
    echo "目录：$ATRIA_DIR"
    echo "版本：$(current_ref_label)"
    if ! repo_ok; then
        echo -e "状态：${YELLOW}未安装${NC}"
        return 0
    fi

    local port pid pids
    port=$(get_port)
    pid=$(read_pid 2>/dev/null || true)
    pids=$(find_atria_pids)
    echo "端口：$port"
    echo "存储：$(get_storage_mode)"
    echo "数据：$(resolve_config_data_dir 2>/dev/null || echo 未配置)"
    echo "备份：$BACKUP_DIR"

    if [ -n "$pid" ]; then
        if [ -f "$KEEPALIVE_FLAG_FILE" ]; then
            echo -e "状态：${GREEN}运行中${NC}（保活后台，PID $pid）"
        else
            echo -e "状态：${GREEN}运行中${NC}（普通后台，PID $pid）"
        fi
    elif [ -n "$pids" ]; then
        if [ -f "$KEEPALIVE_FLAG_FILE" ]; then
            echo -e "状态：${GREEN}运行中${NC}（保活模式，PID: $(echo "$pids" | tr '\n' ' ')）"
        else
            echo -e "状态：${GREEN}运行中${NC}（前台/外部进程，PID: $(echo "$pids" | tr '\n' ' ')）"
        fi
    else
        echo -e "状态：${RED}未运行${NC}"
    fi
}

show_logs() {
    if [ ! -f "$LOG_FILE" ]; then
        warn "尚无后台日志：$LOG_FILE"
        return 0
    fi
    echo -e "${DIM}Ctrl+C 退出实时日志，不会停止 Atria。${NC}"
    tail -n 120 -f "$LOG_FILE"
}

open_browser() {
    local url="http://127.0.0.1:$(get_port)"
    info "打开：$url"
    if command -v termux-open-url >/dev/null 2>&1; then
        termux-open-url "$url"
    elif command -v am >/dev/null 2>&1; then
        am start -a android.intent.action.VIEW -d "$url" >/dev/null 2>&1 || true
    else
        echo "$url"
    fi
}

process_menu() {
    while true; do
        clear
        echo -e "${CYAN}========== Atria 运行管理 ==========${NC}"
        atria_status
        echo ""
        echo "1. 保活启动（推荐）"
        echo "2. 普通后台启动"
        echo "3. 前台调试启动"
        echo "4. 停止 Atria"
        echo "5. 重启（保持当前模式）"
        echo "6. 查看后台日志"
        echo "7. 打开 Atria 网页"
        echo "0. 返回"
        read -r -p "请选择：" choice
        case "$choice" in
            1) start_keepalive; pause ;;
            2) start_background; pause ;;
            3) start_foreground; pause ;;
            4) stop_atria; pause ;;
            5) restart_current_mode; pause ;;
            6) show_logs ;;
            7) open_browser; pause ;;
            0) return ;;
            *) error "无效选项"; pause ;;
        esac
    done
}

# ---------- 数据管理 ----------
verify_current_data_setup() {
    ensure_repo || return 1
    ensure_shared_storage || return 1
    ensure_config
    refresh_instance_storage_paths
    local current target
    current=$(resolve_config_data_dir)
    target="$ATRIA_DATA_DIR"
    if [ "$(get_abs_path "$current" 2>/dev/null || echo "$current")" != "$(get_abs_path "$target" 2>/dev/null || echo "$target")" ]; then
        error "dataRoot 尚未指向当前实例的共享目录。"
        echo "当前：$current"
        echo "目标：$target"
        return 1
    fi

    local test_file="$target/.atria-data-write-test.$$"
    printf 'ok' > "$test_file" 2>/dev/null || { error "共享 data 不可写。"; return 1; }
    rm -f "$test_file"
    local count size
    count=$(find "$target" -type f 2>/dev/null | wc -l | tr -d ' ')
    size=$(du -sh "$target" 2>/dev/null | awk '{print $1}')
    info "数据目录正常。文件数：${count:-0}，大小：${size:-未知}"
    echo "路径：$(get_abs_path "$target" 2>/dev/null || echo "$target")"
}

data_management_menu() {
    while true; do
        clear
        echo -e "${CYAN}========== Atria 数据管理 ==========${NC}"
        show_storage_status
        echo ""
        echo "1. 创建备份"
        echo "2. 恢复备份"
        echo "3. 初始化 / 迁移到 Android 共享存储"
        echo "4. 校验当前数据位置与写入权限"
        echo "5. 查看共享目录内容"
        echo "6. 清理迁移后保留的旧 Termux 私有 data"
        echo "0. 返回"
        read -r -p "请选择：" choice
        case "$choice" in
            1) backup_data; pause ;;
            2) restore_data; pause ;;
            3) migrate_private_data_to_shared; pause ;;
            4) verify_current_data_setup; pause ;;
            5)
                ensure_shared_storage && {
                    echo "路径：$(get_abs_path "$ATRIA_SHARED_DIR" 2>/dev/null || echo "$ATRIA_SHARED_DIR")"
                    ls -lah "$ATRIA_SHARED_DIR" 2>/dev/null
                }
                pause
                ;;
            6) cleanup_private_data_backups; pause ;;
            0) return ;;
            *) error "无效选项"; pause ;;
        esac
    done
}

# ---------- 配置 / 诊断 ----------
change_port() {
    ensure_repo || return 1
    ensure_config
    local current new
    current=$(get_port)
    info "当前端口：$current"
    read -r -p "输入新端口 (1024-65535)：" new
    [[ "$new" =~ ^[0-9]+$ ]] || { error "端口必须是数字。"; return 1; }
    [ "$new" -ge 1024 ] && [ "$new" -le 65535 ] || { error "端口范围应为 1024-65535。"; return 1; }
    if [ "$new" != "$current" ] && [ -n "$(port_pids "$new")" ]; then
        error "端口 $new 已被占用。"
        return 1
    fi
    set_port_value "$new" || return 1
    info "端口已改为 $new。重启 Atria 后生效。"
}

health_check() {
    local ok_count=0 warn_count=0 fail_count=0
    local mark_ok mark_warn mark_fail
    mark_ok()   { echo -e "${GREEN}[OK]${NC} $*"; ok_count=$((ok_count+1)); }
    mark_warn() { echo -e "${YELLOW}[WARN]${NC} $*"; warn_count=$((warn_count+1)); }
    mark_fail() { echo -e "${RED}[FAIL]${NC} $*"; fail_count=$((fail_count+1)); }

    echo -e "${CYAN}========== Atria 环境诊断 ==========${NC}"
    is_termux && mark_ok "Termux 环境" || mark_warn "当前环境不像标准 Termux"

    local major
    major=$(node_major)
    if [ "$major" -ge 20 ] 2>/dev/null; then
        mark_ok "Node.js $(node -v 2>/dev/null)"
    else
        mark_fail "Node.js 需要 >=20，当前：$(node -v 2>/dev/null || echo 未安装)"
    fi

    local cmd missing=()
    for cmd in git curl npm python tar jq lsof fuser pgrep; do
        command -v "$cmd" >/dev/null 2>&1 || missing+=("$cmd")
    done
    [ ${#missing[@]} -eq 0 ] && mark_ok "基础命令完整" || mark_fail "缺少命令：${missing[*]}"

    if [ -d "$SHARED_STORAGE_LINK" ]; then
        mark_ok "Android 共享存储已授权"
    else
        mark_warn "共享存储尚未初始化（可执行 termux-setup-storage）"
    fi

    if repo_ok; then
        mark_ok "Atria 仓库完整：$(current_ref_label)"
        [ -d "$ATRIA_DIR/node_modules" ] && mark_ok "node_modules 已存在" || mark_warn "node_modules 缺失"

        local current target
        current=$(resolve_config_data_dir 2>/dev/null || echo '-')
        target=$(get_abs_path "$ATRIA_DATA_DIR" 2>/dev/null || echo "$ATRIA_DATA_DIR")
        if [ "$(get_abs_path "$current" 2>/dev/null || echo "$current")" = "$target" ]; then
            mark_ok "数据已分离到共享存储"
        else
            mark_fail "dataRoot 未指向共享目录：$current"
        fi

        local port pids own foreign="" p
        port=$(get_port)
        pids=$(port_pids "$port")
        own=$(find_atria_pids)
        for p in $pids; do
            echo "$own" | grep -qx "$p" || foreign="$foreign $p"
        done
        if [ -z "$foreign" ]; then
            mark_ok "端口 $port 无外部冲突"
        else
            mark_fail "端口 $port 被其他进程占用：$foreign"
        fi
    else
        mark_warn "当前实例尚未安装 Atria"
    fi

    cleanup_stale_keepalive_flags
    if [ -f "$KEEPALIVE_FLAG_FILE" ]; then
        mark_ok "当前实例处于工具箱保活模式"
    else
        mark_warn "当前实例未启用工具箱保活模式"
    fi

    echo ""
    echo "诊断汇总：OK=$ok_count WARN=$warn_count FAIL=$fail_count"
    [ "$fail_count" -eq 0 ]
}

repair_environment() {
    info "开始一键修复运行环境..."
    init_environment || return 1
    ensure_shared_storage || return 1
    if repo_ok; then
        ensure_config
        ensure_instance_default_port
        ensure_data_separation || return 1
        local running
        running=$(find_atria_pids)
        if [ -n "$running" ]; then
            confirm "修复依赖前停止正在运行的 Atria？" y || return 1
            stop_atria || return 1
        fi
        install_node_modules || return 1
    fi
    info "环境修复完成。"
}

rebuild_node_modules() {
    ensure_repo || return 1
    local running
    running=$(find_atria_pids)
    if [ -n "$running" ]; then
        confirm "重建依赖前停止 Atria？" y || return 1
        stop_atria || return 1
    fi
    confirm "删除 node_modules 并重新安装生产依赖？" y || return 1
    rm -rf "$ATRIA_DIR/node_modules"
    install_node_modules
}

install_repair_menu() {
    while true; do
        clear
        echo -e "${CYAN}========== Atria 安装 / 修复 ==========${NC}"
        echo "当前：$(current_ref_label)"
        echo "1. 安装 / 重装 Atria（默认 main）"
        echo "2. 一键修复运行环境"
        echo "3. 重建 npm 依赖"
        echo "0. 返回"
        read -r -p "请选择：" choice
        case "$choice" in
            1) install_atria; pause ;;
            2) repair_environment; pause ;;
            3) rebuild_node_modules; pause ;;
            0) return ;;
            *) error "无效选项"; pause ;;
        esac
    done
}

android_runtime_status() {
    cleanup_stale_keepalive_flags
    echo -e "${BOLD}当前实例保活：${NC}$([ -f "$KEEPALIVE_FLAG_FILE" ] && echo 已启用 || echo 未启用)"
    echo -e "${BOLD}主实例保活：${NC}$([ -f "$KEEPALIVE_MAIN_FLAG" ] && echo 已启用 || echo 未启用)"
    echo -e "${BOLD}分身实例保活：${NC}$([ -f "$KEEPALIVE_SECOND_FLAG" ] && echo 已启用 || echo 未启用)"
    echo -e "${BOLD}电池引导：${NC}$([ -f "$BATTERY_GUIDE_FLAG" ] && echo 已显示过 || echo 尚未显示)"
    echo -e "${BOLD}Wake Lock 管理标记：${NC}$([ -f "$WAKELOCK_MANAGED_FLAG" ] && echo 工具箱已请求 || echo 工具箱未持有)"
    echo "注：管理标记代表工具箱的请求状态，不冒充 Android 内核的实时锁状态。"
}

android_runtime_menu() {
    while true; do
        clear
        echo -e "${CYAN}========== Android 后台设置 ==========${NC}"
        android_runtime_status
        echo ""
        echo "1. 打开 Termux 电池 / 后台设置"
        echo "2. 重新显示电池优化引导"
        echo "3. 为现有保活实例重新获取 Wake Lock"
        echo "4. 释放 Wake Lock（仅无保活实例时）"
        echo "5. 显示手机端保活建议"
        echo "0. 返回"
        read -r -p "请选择：" choice
        case "$choice" in
            1) open_termux_battery_settings || true; pause ;;
            2) rm -f "$BATTERY_GUIDE_FLAG"; ensure_battery_guide; pause ;;
            3)
                if any_keepalive_enabled; then
                    if ensure_wake_lock_cli && termux-wake-lock >/dev/null 2>&1; then
                        touch "$WAKELOCK_MANAGED_FLAG"
                        info "已重新请求 Wake Lock。"
                    fi
                else
                    warn "当前没有工具箱保活实例，不需要持有 Wake Lock。"
                fi
                pause
                ;;
            4)
                if any_keepalive_enabled; then
                    warn "仍有保活实例运行，为避免误杀保活，不释放 Wake Lock。"
                else
                    if [ -f "$WAKELOCK_MANAGED_FLAG" ]; then
                        ensure_wake_lock_cli && termux-wake-unlock >/dev/null 2>&1 || true
                        rm -f "$WAKELOCK_MANAGED_FLAG"
                        info "已请求释放工具箱管理的 Wake Lock。"
                    else
                        info "工具箱当前没有管理中的 Wake Lock。"
                    fi
                fi
                pause
                ;;
            5) show_battery_guide; pause ;;
            0) return ;;
            *) error "无效选项"; pause ;;
        esac
    done
}

show_path_info() {
    refresh_instance_storage_paths
    echo "程序：$ATRIA_DIR"
    echo "配置：$ATRIA_DIR/config.yaml"
    echo "数据：$(resolve_config_data_dir 2>/dev/null || echo 未配置)"
    echo "共享根：$(get_abs_path "$ATRIA_SHARED_DIR" 2>/dev/null || echo "$ATRIA_SHARED_DIR")"
    echo "备份：$(get_abs_path "$BACKUP_DIR" 2>/dev/null || echo "$BACKUP_DIR")"
    echo "日志：$LOG_FILE"
    echo "PID：$PID_FILE"
    echo "工具箱：$TOOLBOX_PATH"
}

settings_diagnostics_menu() {
    while true; do
        clear
        echo -e "${CYAN}========== 设置 / 诊断 ==========${NC}"
        echo "当前端口：$(get_port)"
        echo "1. 全面环境诊断"
        echo "2. 修改端口"
        echo "3. 检查端口占用"
        echo "4. Android 后台 / 电池设置"
        echo "5. 查看程序、数据、备份路径"
        echo "0. 返回"
        read -r -p "请选择：" choice
        case "$choice" in
            1) health_check; pause ;;
            2) change_port; pause ;;
            3) show_port_usage; pause ;;
            4) android_runtime_menu ;;
            5) show_path_info; pause ;;
            0) return ;;
            *) error "无效选项"; pause ;;
        esac
    done
}

# ---------- 工具箱自安装 / 自更新 / 自动进入 ----------
install_self() {
    local current=""
    if [ -e "$0" ]; then
        current=$(get_abs_path "$0" 2>/dev/null || true)
    fi

    if [ -n "$current" ] && [ -f "$current" ]; then
        if [ "$current" != "$TOOLBOX_PATH" ]; then
            cp "$current" "$TOOLBOX_PATH" || return 1
            chmod +x "$TOOLBOX_PATH"
            info "工具箱已保存到：$TOOLBOX_PATH"
        fi
        return 0
    fi

    info "当前为临时执行，正在保存工具箱到 Termux HOME..."
    local tmp="$TOOLBOX_PATH.tmp.$$"
    curl -fsSL "$SCRIPT_URL" -o "$tmp" || { rm -f "$tmp"; return 1; }
    bash -n "$tmp" || { rm -f "$tmp"; error "下载脚本语法检查失败。"; return 1; }
    mv "$tmp" "$TOOLBOX_PATH"
    chmod +x "$TOOLBOX_PATH"
    info "工具箱已保存到：$TOOLBOX_PATH"
}

update_self() {
    info "当前工具箱：$SCRIPT_VERSION"
    local tmp="$TOOLBOX_PATH.tmp.$$" remote_version
    if ! curl -fsSL "$SCRIPT_URL" -o "$tmp"; then
        rm -f "$tmp"
        error "无法下载工具箱更新：$SCRIPT_URL"
        return 1
    fi

    grep -q '^#!/.*bash' "$tmp" || { rm -f "$tmp"; error "下载内容不是 Bash 脚本。"; return 1; }
    bash -n "$tmp" || { rm -f "$tmp"; error "新工具箱语法检查失败，旧版本保持不变。"; return 1; }
    remote_version=$(grep -m1 '^SCRIPT_VERSION=' "$tmp" | cut -d'"' -f2)
    [ -n "$remote_version" ] && info "远程工具箱：$remote_version"

    mv "$tmp" "$TOOLBOX_PATH"
    chmod +x "$TOOLBOX_PATH"
    info "工具箱更新完成，正在重新载入。"
    exec bash "$TOOLBOX_PATH" --skip-init
}

remove_autostart_blocks() {
    local file="$1"
    [ -f "$file" ] || return 0
    local tmp="$file.atria_tmp.$$"
    awk '
        /^# BEGIN ATRIA_TOOLBOX_AUTOSTART$/ {skip=1; next}
        /^# END ATRIA_TOOLBOX_AUTOSTART$/   {skip=0; next}
        !skip {print}
    ' "$file" > "$tmp" && mv "$tmp" "$file"
}

autostart_file() {
    if [ -n "${ZSH_VERSION:-}" ] || [[ "${SHELL:-}" == *zsh ]]; then
        echo "$HOME/.zshrc"
    else
        echo "$HOME/.bashrc"
    fi
}

enable_toolbox_autostart() {
    install_self || return 1
    local rc
    rc=$(autostart_file)
    touch "$rc"
    remove_autostart_blocks "$rc"
    cat >> "$rc" <<'BLOCK'
# BEGIN ATRIA_TOOLBOX_AUTOSTART
if [ -t 0 ] && [ -z "$TMUX" ] && [ -z "$ATRIA_TOOLBOX_SESSION_GUARD" ]; then
    export ATRIA_TOOLBOX_SESSION_GUARD=1
    [ -f "$HOME/atria_toolbox.sh" ] && bash "$HOME/atria_toolbox.sh" --skip-init
fi
# END ATRIA_TOOLBOX_AUTOSTART
BLOCK
    info "已开启：打开 Termux 后自动进入 Atria 工具箱。"
}

disable_toolbox_autostart() {
    remove_autostart_blocks "$HOME/.bashrc"
    remove_autostart_blocks "$HOME/.zshrc"
    info "已关闭：打开 Termux 自动进入工具箱。"
}

autostart_enabled() {
    grep -q '^# BEGIN ATRIA_TOOLBOX_AUTOSTART$' "$HOME/.bashrc" 2>/dev/null || \
    grep -q '^# BEGIN ATRIA_TOOLBOX_AUTOSTART$' "$HOME/.zshrc" 2>/dev/null
}

toggle_autostart() {
    if autostart_enabled; then
        disable_toolbox_autostart
    else
        enable_toolbox_autostart
    fi
}

# ---------- 实例 ----------
set_instance() {
    local which="$1"
    if [ "$which" = "second" ]; then
        ATRIA_DIR="$ATRIA_SECOND_DIR"
        CURRENT_INSTANCE="分身实例 (Atria-2)"
        PID_FILE="$TOOLBOX_HOME/atria-2.pid"
        LOG_FILE="$TOOLBOX_HOME/atria-2.log"
        KEEPALIVE_FLAG_FILE="$KEEPALIVE_SECOND_FLAG"
    else
        ATRIA_DIR="$ATRIA_MAIN_DIR"
        CURRENT_INSTANCE="主实例 (Atria)"
        PID_FILE="$TOOLBOX_HOME/atria.pid"
        LOG_FILE="$TOOLBOX_HOME/atria.log"
        KEEPALIVE_FLAG_FILE="$KEEPALIVE_MAIN_FLAG"
    fi
    refresh_instance_storage_paths
}

toggle_instance() {
    if [ "$ATRIA_DIR" = "$ATRIA_MAIN_DIR" ]; then
        set_instance second
    else
        set_instance main
    fi
    info "已切换到：$CURRENT_INSTANCE"
}

# ---------- 卸载 ----------
uninstall_menu() {
    while true; do
        clear
        echo -e "${CYAN}========== 卸载管理 ==========${NC}"
        echo "1. 删除当前 Atria 程序（保留共享数据）"
        echo "2. 删除工具箱与自动进入配置"
        echo "3. 删除当前 Atria 程序 + 工具箱（保留共享数据）"
        echo "4. 永久删除当前实例共享数据与备份"
        echo "0. 返回"
        local choice
        read -r -p "请选择：" choice
        case "$choice" in
            1)
                safe_delete_confirm "删除 $ATRIA_DIR" || continue
                stop_atria || true
                rm -rf "$ATRIA_DIR"
                info "程序已删除；共享数据仍保留：$ATRIA_SHARED_DIR"
                pause
                ;;
            2)
                safe_delete_confirm "删除 Atria 工具箱" || continue
                disable_toolbox_autostart
                rm -f "$TOOLBOX_PATH"
                info "工具箱已删除。"
                exit 0
                ;;
            3)
                safe_delete_confirm "删除 $ATRIA_DIR 和 Atria 工具箱" || continue
                stop_atria || true
                rm -rf "$ATRIA_DIR"
                disable_toolbox_autostart
                rm -f "$TOOLBOX_PATH"
                info "程序与工具箱已删除；共享数据仍保留：$ATRIA_SHARED_DIR"
                exit 0
                ;;
            4)
                ensure_shared_storage || { pause; continue; }
                safe_delete_confirm "永久删除 $ATRIA_SHARED_DIR（data/backups/exports）" || continue
                stop_atria || true
                rm -rf "$ATRIA_SHARED_DIR"
                info "共享数据已永久删除。"
                pause
                ;;
            0) return ;;
            *) error "无效选项"; pause ;;
        esac
    done
}

toolbox_info() {
    echo "版本：$SCRIPT_VERSION"
    echo "本地：$TOOLBOX_PATH"
    echo "更新源：$SCRIPT_URL"
    echo "项目：$REPO_URL"
    echo "默认分支：$DEFAULT_BRANCH"
}

toolbox_settings_menu() {
    while true; do
        clear
        local auto="OFF"
        autostart_enabled && auto="ON"
        echo -e "${CYAN}========== 工具箱设置 ==========${NC}"
        echo "版本：$SCRIPT_VERSION"
        echo "1. 更新工具箱"
        echo "2. 打开 Termux 自动进入工具箱 [$auto]"
        echo "3. 查看工具箱信息"
        echo "4. 卸载管理"
        echo "0. 返回"
        read -r -p "请选择：" choice
        case "$choice" in
            1) update_self; pause ;;
            2) toggle_autostart; pause ;;
            3) toolbox_info; pause ;;
            4) uninstall_menu ;;
            0) return ;;
            *) error "无效选项"; pause ;;
        esac
    done
}

main_status_line() {
    cleanup_stale_keepalive_flags
    if ! repo_ok; then
        echo "未安装"
        return
    fi
    local pids
    pids=$(find_atria_pids)
    if [ -z "$pids" ]; then
        echo "未运行"
    elif [ -f "$KEEPALIVE_FLAG_FILE" ]; then
        echo "运行中 · 保活"
    elif read_pid >/dev/null 2>&1; then
        echo "运行中 · 后台"
    else
        echo "运行中 · 前台/外部"
    fi
}

# ---------- 主菜单 ----------
main_menu() {
    while true; do
        refresh_instance_storage_paths
        clear
        echo -e "${CYAN}"
        echo " _          _             "
        echo "| |   _   _| | _____ _ __ "
        echo "| |  | | | | |/ / _ \\ '__|"
        echo "| |__| |_| |   <  __/ |   "
        echo "|_____\\__,_|_|\\_\\___|_|   "
        echo -e "${NC}"
        echo -e "${CYAN}====================================================${NC}"
        echo -e "${BOLD}${PURPLE} Atria Termux 工具箱 ${NC} ${YELLOW}${SCRIPT_VERSION}${NC}"
        echo -e "${CYAN}====================================================${NC}"
        echo -e "实例：${YELLOW}$CURRENT_INSTANCE${NC}"
        echo -e "状态：${YELLOW}$(main_status_line)${NC}"
        echo -e "版本：${BLUE}$(current_ref_label)${NC}"
        echo -e "数据：${CYAN}$(get_abs_path "$ATRIA_DATA_DIR" 2>/dev/null || echo "$ATRIA_DATA_DIR")${NC}"
        echo -e "${CYAN}----------------------------------------------------${NC}"
        echo "1. 运行管理"
        echo "2. 安装 / 修复"
        echo "3. 版本管理"
        echo "4. 数据管理"
        echo "5. 设置 / 诊断"
        echo "6. 工具箱设置"
        echo "7. 切换主实例 / 分身实例"
        echo "0. 退出"
        echo -e "${CYAN}====================================================${NC}"

        local option
        read -r -p "请输入选项 [0-7]：" option
        case "$option" in
            1) process_menu ;;
            2) install_repair_menu ;;
            3) version_menu ;;
            4) data_management_menu ;;
            5) settings_diagnostics_menu ;;
            6) toolbox_settings_menu ;;
            7) toggle_instance; sleep 1 ;;
            0) exit 0 ;;
            *) error "无效选项"; pause ;;
        esac
    done
}

# ---------- 入口 ----------
set_instance main
cleanup_stale_keepalive_flags
release_wake_lock_if_unused

# 无论是否 --skip-init，都先确保本地保存的是完整运行时脚本。
# 这样仓库入口即使使用轻量启动器，自更新后也会自动落盘为完整工具箱。
install_self || warn "工具箱未能保存到 $TOOLBOX_PATH；本次临时会话仍可继续。"

if [ "${1:-}" != "--skip-init" ]; then
    init_environment || {
        warn "环境检查未完全通过。你仍可进入工具箱进行安装或修复。"
        pause
    }
fi

if repo_ok; then
    ensure_config
    local_current_data="$(resolve_config_data_dir 2>/dev/null || echo ./data)"
    if [ "$(get_abs_path "$local_current_data" 2>/dev/null || echo "$local_current_data")" != "$(get_abs_path "$ATRIA_DATA_DIR" 2>/dev/null || echo "$ATRIA_DATA_DIR")" ]; then
        warn "检测到数据仍位于旧位置：$local_current_data"
        info "启动 Atria 前，工具箱会引导迁移到 Android 共享存储。"
        sleep 2
    fi
fi

main_menu
